var AWS=require('aws-sdk');
var s3 = new AWS.S3();
var nodemailer = require('nodemailer');
exports.handler = function(event, context, callback) {
const bucket = event.Records[0].s3.bucket.name;
    
    //console.log('Name of S3 bucket is:', bucket);
    const key = decodeURIComponent(event.Records[0].s3.object.key.replace(/\+/g, ' '));
    const params = {
        Bucket: bucket,
        Key: key,
    };
 console.log(JSON.stringify(params));
s3.getObject(params, function(err, data) {
  if (err) {
   console.log(JSON.stringify(err));
    // error handling
  } else {
    console.log('in s3');
var updatedFileName = key.replace(/^.*[\\\/]/, ''); 
    var attachmentsData = {
      content: data.Body,
      filename: updatedFileName,
      contentType: data.ContentType,
    };

var smtpConfig = {
    host: 'smtp.emailsrvr.com',
    port: 25,
    secure: false, // do not use SSL
    auth: {          
         user: 'cync.core@idexcel.com',
         pass: 'Idapr$15'
    },
    ignoreTLS: true,
    authMethod: 'LOGIN'
};

    var transporter;
    transporter = nodemailer.createTransport(smtpConfig);

    // setup e-mail data with unicode symbols
    var mailOptions;
   
          mailOptions = {
            from: 'cync.core@idexcel.com',            					     
	     to: 'vamsi.nukala@idexcel.com,pkuninti@cyncsoftware.com,abhilash.ma@idexcel.com,ranjithkumar.ravi@idexcel.com,madhan.ayyasamy@idexcel.com,vigram.karuppiah@idexcel.com,suresh.masilamani@idexcel.com',
            replyTo: '',
            subject: 'slowquery_log',            
            //text: '', // plaintext body
            html: 'please find the attached yesterday\'s slow query log file', // html body
            attachments : attachmentsData
        };
       

        // send mail with defined transport object
        transporter.sendMail(mailOptions, function(error, info){
            if(error){
                console.log( 'From : ' + mailOptions.from + ', ' + 'To : ' + mailOptions.to);
                console.log( 'Sub : ' + mailOptions.subject + ', ' + 'Content : ' + mailOptions.html);
                console.log('Err:' + JSON.stringify(error));
                console.log(JSON.stringify( error));
            }
            else
            {
            console.log('Success');
          }
        }
            
        );
    }
});
};
