module.exports.handler = async event => {
  return {
    statusCode: 200,
    body: JSON.stringify(
      {
        message: playerList()
      },
      null,
      2
    )
  };

 

};const playerList = () => {
  return [
    { name: "Hima", number: 23 },
    { name: "pradeeptha", number: 11 },
    { name: "Sonali", number: 33 }
  ];
};
